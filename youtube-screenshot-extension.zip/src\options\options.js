/**
 * options.js
 * Handles all logic for the extension settings page:
 *   - Saving / loading the OpenAI API key
 *   - Testing the API connection
 *   - Toggling key visibility
 *   - Sidebar navigation
 *   - Saving user preferences
 */
import './options.css';
import { getAllSubjects, addSubject, deleteSubject } from '../storage/storage.js';

// =====================
// DOM References
// =====================
document.addEventListener('DOMContentLoaded', () => {
  const apiKeyInput    = document.getElementById('api-key-input');
  const modelSelect    = document.getElementById('model-select');
  const toggleVisBtn   = document.getElementById('toggle-visibility');
  const eyeIcon        = document.getElementById('eye-icon');
  const saveApiBtn     = document.getElementById('save-api-btn');
  const testApiBtn     = document.getElementById('test-api-btn');
  const apiStatus      = document.getElementById('api-status');

  const prefAutopause  = document.getElementById('pref-autopause');
  const prefQuality    = document.getElementById('pref-quality');
  const savePrefsBtn   = document.getElementById('save-prefs-btn');
  const prefsStatus    = document.getElementById('prefs-status');
  
  const msClientIdInput = document.getElementById('microsoft-client-id');
  const msLoginBtn      = document.getElementById('ms-login-btn');
  const saveMsBtn       = document.getElementById('save-ms-btn');
  const msStatus        = document.getElementById('ms-status');

  const subjectInput    = document.getElementById('subject-name-input');
  const addSubjectBtn   = document.getElementById('add-subject-btn');
  const subjectsList    = document.getElementById('subjects-list');
  const subjectsEmpty   = document.getElementById('subjects-empty');
  const subjectsStatus  = document.getElementById('subjects-status');

  const navLinks       = document.querySelectorAll('.nav-link');

  // =====================
  // Sidebar navigation
  // =====================
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const sectionId = link.dataset.section;

      // Toggle active nav
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');

      // Toggle active section
      document.querySelectorAll('.settings-section').forEach(s => s.classList.remove('active'));
      document.getElementById(`section-${sectionId}`).classList.add('active');
    });
  });

  // =====================
  // Load saved settings
  // =====================
  chrome.storage.local.get(['openai_api_key', 'openai_model', 'pref_autopause', 'pref_quality', 'microsoft_client_id'], (data) => {
    if (data.openai_api_key) {
      apiKeyInput.value = data.openai_api_key;
    }
    if (data.openai_model) {
      modelSelect.value = data.openai_model;
    }
    if (typeof data.pref_autopause === 'boolean') {
      prefAutopause.checked = data.pref_autopause;
    }
    if (data.pref_quality) {
      prefQuality.value = data.pref_quality;
    }
    if (data.microsoft_client_id) {
      msClientIdInput.value = data.microsoft_client_id;
    }
  });

  // =====================
  // Toggle key visibility
  // =====================
  toggleVisBtn.addEventListener('click', () => {
    const isPassword = apiKeyInput.type === 'password';
    apiKeyInput.type = isPassword ? 'text' : 'password';
    eyeIcon.textContent = isPassword ? '🙈' : '👁️';
  });

  // =====================
  // Save API settings
  // =====================
  saveApiBtn.addEventListener('click', () => {
    const key   = apiKeyInput.value.trim();
    const model = modelSelect.value;

    if (!key) {
      showStatus(apiStatus, 'error', 'Please enter an API key.');
      return;
    }

    if (!key.startsWith('gsk_')) {
      showStatus(apiStatus, 'error', 'Invalid key format. Groq keys start with "gsk_".');
      return;
    }

    chrome.storage.local.set({ openai_api_key: key, openai_model: model }, () => {
      showStatus(apiStatus, 'success', '✅ Settings saved successfully!');
    });
  });

  // =====================
  // Test API connection
  // =====================
  testApiBtn.addEventListener('click', async () => {
    const key = apiKeyInput.value.trim();

    if (!key) {
      showStatus(apiStatus, 'error', 'Enter an API key before testing.');
      return;
    }

    // Show loading state
    testApiBtn.disabled = true;
    testApiBtn.innerHTML = '<span class="spinner"></span> Testing...';
    showStatus(apiStatus, 'info', 'Connecting to Groq...');

    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: modelSelect.value,
          messages: [{ role: 'user', content: 'Say "connected" in one word.' }],
          max_tokens: 5
        })
      });

      if (response.ok) {
        const data = await response.json();
        const reply = data.choices?.[0]?.message?.content || 'OK';
        showStatus(apiStatus, 'success', `✅ Connection successful! Model replied: "${reply.trim()}"`);
      } else {
        const err = await response.json().catch(() => ({}));
        const msg = err.error?.message || `HTTP ${response.status}`;
        showStatus(apiStatus, 'error', `❌ API error: ${msg}`);
      }
    } catch (e) {
      showStatus(apiStatus, 'error', `❌ Network error: ${e.message}`);
    } finally {
      testApiBtn.disabled = false;
      testApiBtn.innerHTML = 'Test Connection';
    }
  });

  // =====================
  // Save preferences
  // =====================
  savePrefsBtn.addEventListener('click', () => {
    chrome.storage.local.set({
      pref_autopause: prefAutopause.checked,
      pref_quality: prefQuality.value
    }, () => {
      showStatus(prefsStatus, 'success', '✅ Preferences saved!');
    });
  });

  // =====================
  // Microsoft Intg
  // =====================
  saveMsBtn.addEventListener('click', () => {
    const clientId = msClientIdInput.value.trim();
    if (!clientId) {
      showStatus(msStatus, 'error', 'Please enter a Client ID.');
      return;
    }
    chrome.storage.local.set({ microsoft_client_id: clientId }, () => {
      showStatus(msStatus, 'success', '✅ Client ID saved locally.');
    });
  });

  msLoginBtn.addEventListener('click', () => {
    const clientId = msClientIdInput.value.trim();
    if (!clientId) {
      showStatus(msStatus, 'error', 'You must enter your Azure Client ID first.');
      return;
    }
    
    // Save it first
    chrome.storage.local.set({ microsoft_client_id: clientId });
    
    showStatus(msStatus, 'info', 'Opening Microsoft Login...');
    
    const redirectUrl = chrome.identity.getRedirectURL();
    console.log('[Auth] Custom Redirect URI generated:', redirectUrl);
    
    const authUrl = new URL('https://login.microsoftonline.com/common/oauth2/v2.0/authorize');
    authUrl.searchParams.set('client_id', clientId);
    authUrl.searchParams.set('response_type', 'token');
    authUrl.searchParams.set('redirect_uri', redirectUrl);
    authUrl.searchParams.set('scope', 'Notes.Create Notes.ReadWrite User.Read');

    chrome.identity.launchWebAuthFlow({
      url: authUrl.href,
      interactive: true
    }, (redirectResponse) => {
      if (chrome.runtime.lastError || !redirectResponse) {
        showStatus(msStatus, 'error', `Auth Error: ${chrome.runtime.lastError?.message || 'Login cancelled.'}`);
        return;
      }
      
      // Extract the token from the #hash in the resulting URL
      const hashParams = new URL(redirectResponse).hash.substring(1);
      const params = new URLSearchParams(hashParams);
      const token = params.get('access_token');
      
      if (token) {
        chrome.storage.local.set({ microsoft_token: token }, () => {
          showStatus(msStatus, 'success', '✅ Successfully connected to Microsoft!');
          msLoginBtn.innerHTML = 'Connected!';
          msLoginBtn.style.background = '#059669'; // Green success
        });
      } else {
        showStatus(msStatus, 'error', 'Failed to retrieve access token from Microsoft.');
      }
    });
  });
  // =====================
  // Subject Management
  // =====================
  async function renderSubjects() {
    const subjects = await getAllSubjects();
    // Clear existing pills (keep the empty message)
    Array.from(subjectsList.children).forEach(el => {
      if (el.id !== 'subjects-empty') el.remove();
    });

    if (subjects.length === 0) {
      if (subjectsEmpty) subjectsEmpty.style.display = 'block';
      return;
    }
    if (subjectsEmpty) subjectsEmpty.style.display = 'none';

    subjects.forEach(name => {
      const pill = document.createElement('div');
      pill.style.cssText = 'display:flex;align-items:center;gap:8px;background:rgba(124,58,237,0.15);border:1px solid rgba(124,58,237,0.4);border-radius:20px;padding:6px 14px;font-size:13px;font-weight:500;color:#c4b5fd;';
      pill.innerHTML = `<span>${name}</span><button data-name="${name}" style="background:none;border:none;color:#f87171;cursor:pointer;font-size:15px;line-height:1;padding:0;" title="Delete">✕</button>`;
      pill.querySelector('button').addEventListener('click', async (e) => {
        const subjectName = e.target.dataset.name;
        await deleteSubject(subjectName);
        // If this was the active subject, reset to General
        chrome.storage.local.get(['active_subject'], (res) => {
          if (res.active_subject === subjectName) {
            chrome.storage.local.set({ active_subject: 'General' });
          }
        });
        await renderSubjects();
        showStatus(subjectsStatus, 'success', `🗑️ "${subjectName}" deleted.`);
      });
      subjectsList.appendChild(pill);
    });
  }

  renderSubjects();

  addSubjectBtn.addEventListener('click', async () => {
    const name = subjectInput.value.trim();
    if (!name) {
      showStatus(subjectsStatus, 'error', 'Please type a subject name.');
      return;
    }
    await addSubject(name);
    subjectInput.value = '';
    await renderSubjects();
    showStatus(subjectsStatus, 'success', `✅ Subject "${name}" added!`);
  });

  // Allow pressing Enter to add
  subjectInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addSubjectBtn.click();
  });
});

// =====================
// Helper: show toast
// =====================
function showStatus(el, type, message) {
  el.className = `status-toast ${type}`;
  el.textContent = message;
  el.classList.remove('hidden');

  // Auto-hide after 5s
  clearTimeout(el._timer);
  el._timer = setTimeout(() => {
    el.classList.add('hidden');
  }, 5000);
}
